package main

import "fmt"

func main() {
	str := "the one"
	fmt.Printf(`You’re %[1]s that I long to kiss, Baby you’re %[1]s that I really miss.
You’re %[1]s that I’m dreamin’ of, Baby, you’re %[1]s that I love!`, str)
}
