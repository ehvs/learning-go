package main

import "fmt"

func main() {
	fmt.Println("Hello World")

	message := "hello"
	num := 42
	num = 13
	fmt.Println(message, num)
}
