package main

import "fmt"

func main() {
	var val1 string = "The gopher is amazing!"
	var val2 rune = 'G'
	var val3 rune = 'o'
	var val4 rune = 'i'
	var val5 rune = 's'
	var val6 string = "great"
	var val7 rune = '!'
	fmt.Println(val1)
	fmt.Println(string(val2))
	fmt.Println(string(val3))
	fmt.Println(string(val4))
	fmt.Println(string(val5))
	fmt.Println(val6)
	fmt.Println(string(val7))
}
