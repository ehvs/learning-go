package main

import "fmt"

func main() {
	var name string = "Sonya Soul"
	var gender string = "Female"
	var age int = 22
	var class string = "Herald"
	var skinColor string = "(0, 0, 255)"

	fmt.Println("Name:", name)
	fmt.Println("Gender:", gender)
	fmt.Println("Age:", age)
	fmt.Println("Class:", class)
	fmt.Println("Skin color:", skinColor)
}
