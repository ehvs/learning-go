package main

import "fmt"

func main() {
	fmt.Println("Is Richie a hooman?")
	var isRichieHooman bool = false
	fmt.Println(isRichieHooman)
	fmt.Println("Richie is a dog!")
	fmt.Println()

	fmt.Println("Is Pres a hooman?")
	var isPresHooman bool = true
	fmt.Println(isPresHooman)
}
