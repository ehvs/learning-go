package main

import "fmt"

func main() {
	num := 123
	lastDigit := num % 10
	fmt.Println(lastDigit)
}
