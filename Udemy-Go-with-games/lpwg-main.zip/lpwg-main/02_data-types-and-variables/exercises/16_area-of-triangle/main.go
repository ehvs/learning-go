package main

import "fmt"

func main() {
	base, height := 3, 5
	area := float64(base*height) / 2
	fmt.Println(area)
}
