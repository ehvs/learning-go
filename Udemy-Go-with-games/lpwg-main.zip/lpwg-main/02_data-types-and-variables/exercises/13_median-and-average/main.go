package main

import "fmt"

func main() {
	n1, n2, n3 := 3, 18, 23
	fmt.Println("Median:", n2)

	avg := float64(n1+n2+n3) / 3
	fmt.Println(avg)
}
