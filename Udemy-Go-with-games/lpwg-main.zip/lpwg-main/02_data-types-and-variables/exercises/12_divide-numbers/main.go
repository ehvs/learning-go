package main

import "fmt"

func main() {
	fmt.Println(13 / 3)
	fmt.Println(13.0 / 3.0)
}
