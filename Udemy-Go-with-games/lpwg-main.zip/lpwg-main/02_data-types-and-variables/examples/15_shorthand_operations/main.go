package main

import "fmt"

func main() {
	var a, b, c, d int

	// Longer version: a = a + 5
	a += 5

	// Longer version: b = b - 3
	b -= 3

	// Longer version: c = c * 2
	c *= 2

	// Longer version: d = d / 2
	d /= 2

	fmt.Println(a, b, c, d)
}
