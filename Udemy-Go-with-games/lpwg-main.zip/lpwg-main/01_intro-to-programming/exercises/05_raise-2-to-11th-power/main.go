package main

import (
	"fmt"
	"math"
)

func main() {
	res := math.Pow(2, 11)
	fmt.Println(res)
}
