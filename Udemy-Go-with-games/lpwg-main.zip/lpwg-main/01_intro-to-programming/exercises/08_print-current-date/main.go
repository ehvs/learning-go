package main

import (
	"fmt"
	"time"
)

func main() {
	// Get the current time.
	t := time.Now()
	fmt.Println(t)
}
